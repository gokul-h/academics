/*
 * Question based on the code given in Question (Refer PDF in same folder)
 */

