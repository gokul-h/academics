/*  8.
    Given a linked list L, it is well known that accessing the elements one by
    one takes a longer time to access the last element of the list. Device a
    strategy to speed up the process and write a C program to demonstrate your
    principle.
*/
